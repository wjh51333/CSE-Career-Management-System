package participant;

import Account.account;

public class Administrator 
{
	private String name;
	private String adminNum;
	private String job = "Admin";
	
	public String getJob() {
		return job;
	}
	//get set
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdminNum() {
		return adminNum;
	}
	public void setAdminNum(String adminNum) {
		this.adminNum = adminNum;
	}
	//get set
}