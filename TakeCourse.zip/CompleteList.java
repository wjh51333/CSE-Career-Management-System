package TakeCourse;

//�̼� ���
//���̼� ���� �Ǵ�, ���� ���, �ʼ��������Ȯ��, �����߰�, ���� ����
public class CompleteList {

	private int totalgrade;
	private int majorgrade;
	private int refinegrade;
	private int basicrefine;
	private int majorbase;
	private int enginmajor;
	
	
	public int getTotalgrade() {
		return totalgrade;
	}
	public void setTotalgrade(int totalgrade) {
		this.totalgrade = totalgrade;
	}
	public int getMajorgrade() {
		return majorgrade;
	}
	public void setMajorgrade(int majorgrade) {
		this.majorgrade = majorgrade;
	}
	public int getRefinegrade() {
		return refinegrade;
	}
	public void setRefinegrade(int refinegrade) {
		this.refinegrade = refinegrade;
	}
	public int getBasicrefine() {
		return basicrefine;
	}
	public void setBasicrefine(int basicrefine) {
		this.basicrefine = basicrefine;
	}
	public int getMajorbase() {
		return majorbase;
	}
	public void setMajorbase(int majorbase) {
		this.majorbase = majorbase;
	}
	public int getEnginmajor() {
		return enginmajor;
	}
	public void setEnginmajor(int enginmajor) {
		this.enginmajor = enginmajor;
	}
	CourseGrade c=new CourseGrade();
	public int getYearsemester() {
		return c.yearsemester;
	}
	public void setYearsemester(int yearsemester) {
		this.c.yearsemester = yearsemester;
	}
	public String getChecktake() {
		return c.checktake;
	}
	public void setChecktake(String checktake) {
		this.c.checktake = checktake;
	}
	public String getScore() {
		return c.score;
	}
	public void setScore(String score) {
		this.c.score = score;
	}
	CourseInfo i=new CourseInfo();
	public String getCoursename() {
		return i.coursename;
	}
	public void setCoursename(String coursename) {
		this.i.coursename = coursename;
	}
	public String getCoursecode() {
		return i.coursecode;
	}
	public void setCoursecode(String coursecode) {
		this.i.coursecode = coursecode;
	}
	public String getGrade() {
		return i.grade;
	}
	public void setGrade(String grade) {
		this.i.grade = grade;
	}
	
	public void calgrade(String filename) {
		
        String filename2=filename.split(".txt")[0];
        int i,count=0;
        
        Data d=new Data();
		String [] arr=new String[150];
		for (i=0; i<150;i++)
			arr[i]=null;

        arr=d.getfile2(filename);

        d.mdfile(filename2+"��������.txt");
        d.mdfile(filename2+"�⺻�Ҿ�.txt");
        d.mdfile(filename2+"����.txt");
        d.mdfile(filename2+"�������.txt");
        
        for (i=0; i<150;i++)
        	if (arr[i]==null) {
        		count=i;
        		break;
        	}
		
        for(i=0; i<count; i++) {
        		if (arr[i].equals("��������")) {
        			d.setfile(filename2+"��������.txt", arr[i+4]);
        		}
        		if (arr[i].equals("�⺻�Ҿ�")) {
        			d.setfile(filename2+"�⺻�Ҿ�.txt", arr[i+4]);
        		}
        		if (arr[i].equals("�������")) {
        			d.setfile(filename2+"�������.txt", arr[i+4]);
        		}
        		if (arr[i].equals("����")) {
        			d.setfile(filename2+"����.txt", arr[i+5]);
        		}
        		if (arr[i]==null)
        			break;
        }

		enginmajor=d.getfile3(filename2+"��������.txt");
		majorbase=d.getfile3(filename2+"�������.txt");
		basicrefine=d.getfile3(filename2+"�⺻�Ҿ�.txt");
		refinegrade=d.getfile3(filename2+"����.txt");
		
		majorgrade=basicrefine+majorbase+enginmajor;
		totalgrade=majorgrade+refinegrade;
	
	}
}
