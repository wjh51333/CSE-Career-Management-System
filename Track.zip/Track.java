package Track;

public class Track 
{	
	public void print_detailed_graduation_requirement(String filename)
	{
		
	}
	
	public void print_gradution_requirement(String filename)
	{
		
	}
	
	public void print_curriculum(String filename)
	{
		
	}
}
