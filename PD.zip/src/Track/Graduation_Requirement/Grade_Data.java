package Track.Graduation_Requirement;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Grade_Data 
{
	ArrayList <Integer> grade_data_list = new ArrayList <Integer> ();
	
	public ArrayList <Integer> getRequire(String Filename)
	{
		try {
			FileReader fr = new FileReader(Filename);
			BufferedReader br = new BufferedReader(fr);
			grade_data_list.add(0, Integer.parseInt(br.readLine()));
			grade_data_list.add(1, Integer.parseInt(br.readLine()));
			grade_data_list.add(2, Integer.parseInt(br.readLine()));
			fr.close();
			br.close();
		} catch (FileNotFoundException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		}
		
		return grade_data_list;
	}
	
	public void store_grade_data(ArrayList <Integer> newthing, String Filename)
	{
		try {
			File file = new File(Filename);
			file.delete();
			FileWriter fw = new FileWriter(Filename);
			BufferedWriter bw = new BufferedWriter(fw);
			fw.write(newthing.get(0) + "\n");
			fw.write(newthing.get(1) + "\n");
			fw.write(newthing.get(2)+ "\n");
			fw.close();
			bw.close();
		} catch (IOException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		}
	}
}
