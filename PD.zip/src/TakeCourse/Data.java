package TakeCourse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

public class Data {

	private int count=0;
	String [] arr=new String[150];
	String array[][]=new String[150][6];


	public void mdfile2(String filename) {
		File file=new File(filename);
		try {
			FileWriter fw = new FileWriter(filename);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void mdfile(String filename) {
		File file=new File(filename);
		file.delete();
	}
	public String getfile(String filename) {
		StringBuffer buffer = new StringBuffer();
		try {	
			Scanner scan = new Scanner(new FileReader(new File(filename)));
			while(scan.hasNext()){
				buffer.append(scan.nextLine() + ",");
			}
			scan.close();
		}
		catch (FileNotFoundException e) {
			System.out.println("���� �߻�! �����ڿ��� �������ּ���");
			System.exit(0);
		}
			
		String input = buffer.toString().substring(0, buffer.toString().length()-1);
		return input;
	}
	
	public String[] getfile2(String filename) {

		try {
			Scanner scan = new Scanner(new FileReader(new File(filename)));
			while(scan.hasNext()){
	        	arr[count]=scan.next();
	        	count++;
			}
			scan.close();
		} catch (FileNotFoundException e) {
			System.out.println("����! �����ڿ��� �����ϼ���.");
			System.exit(0);
		}
		
		return arr;
	}

	public int getfile3(String filename) {
		Scanner inputStream=null;
		int next, result=0;
        try {
            inputStream = new Scanner(new FileInputStream(filename));
    		while (inputStream.hasNextInt()) {
    			next = inputStream.nextInt( );
    			result+=next;
    	    }
    		inputStream.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println("���� �߻�3! �����ڿ��� �������ּ���");
            System.exit(0);
        }
        return result;
	}
	
	public void setfile(String filename, String str) {
    	PrintWriter outputStream;
		try {
			outputStream = new PrintWriter(new FileWriter(filename, true));
	    	outputStream.println(str);
	    	outputStream.close();
		} catch (IOException e) {
			System.out.println("���� �߻�4! �����ڿ��� �����ϼ���.");
			System.exit(0);
		}
	}

	
	private int yearsemester;
	private String checktake;
	private String score;
	private String coursename;
	private String coursecode;
	private String grade;


	public void addcourse(String filename) {
		
		CourseGrade cg= new CourseGrade();
		CourseInfo ci=new CourseInfo();
		
		System.out.println("�⵵/�б�");
		Scanner keyboard = new Scanner(System.in);
		yearsemester=cg.yearsemester;
		yearsemester = keyboard.nextInt();


		Scanner keyboard2 = new Scanner(System.in);
		System.out.println("��������");			
		checktake=cg.checktake;
		checktake = keyboard2.nextLine();
	
		System.out.println("�����");
		coursename=ci.coursename;
		coursename = keyboard2.nextLine();
		
		System.out.println("�����ڵ�");
		coursecode=ci.coursecode;
		coursecode = keyboard2.nextLine();
		
		System.out.println("����");
		grade=ci.grade;
		grade = keyboard2.nextLine();
		
		System.out.println("����");
		Scanner keyboard3=new Scanner(System.in);
		score=cg.score;
		score = keyboard3.nextLine();


        try  {
        	PrintWriter outputStream = new PrintWriter(new FileWriter(filename, true));
        	outputStream.print(yearsemester+" "+ checktake+" "+score+" "+coursename + " " + coursecode + " " + grade);
        	outputStream.println(" ");
        	outputStream.close();
        }
        catch(FileNotFoundException e) {
            System.out.println("���� �߻�5! �����ڿ��� �������ּ���");
            System.exit(0);
        }
        catch (IOException e) {
        	System.out.println("���� �߻�6! �����ڿ��� �������ּ���");
            System.exit(0);
		}
	}
	

	public void delcourse(String filename) {
		
		String line=null;
		String []arr=new String[1000000];
		int count=0;
		int del_line;
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(filename));
			while((line=br.readLine())!=null) {
				arr[count]=line;
				count++;
			}
			
			br.close();
			
		} catch (FileNotFoundException e1) {
			System.out.println("���� �߻�7! �����ڿ��� �������ּ���");
			System.exit(0);
		} catch (IOException e) {
            System.out.println("���� �߻�8! �����ڿ��� �������ּ���");
            System.exit(0);
        }
		
		
		File file=new File(filename);
		file.delete();
		
		int i;

		Scanner sc=new Scanner(System.in);
		System.out.println("������ �� ��ȣ��? ");
		del_line=sc.nextInt();
		
		try  {
        	PrintWriter outputStream = new PrintWriter(new FileWriter(filename, true));
        	for (i=0; i<del_line; i++) {
        		outputStream.println(arr[i]);
        	}
        	for(i=del_line+1; i<count; i++) {
        		outputStream.println(arr[i]);
        	}
        	outputStream.close();
        }
		
		catch(FileNotFoundException e) {
            System.out.println("���� �߻�9! �����ڿ��� �������ּ���");
            System.exit(0);
        } catch (IOException e) {
			
			e.printStackTrace();
		}
	}
}
