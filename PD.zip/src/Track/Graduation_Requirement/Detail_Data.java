package Track.Graduation_Requirement;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

public class Detail_Data 
{
	HashMap <String, Integer> detail_data_list = new HashMap <String, Integer> ();
	
	public HashMap <String, Integer> open_detail_graduation(String Filename)
	{
		String [] stringarray;
		String str;
		try {
				FileReader fr = new FileReader(Filename);
				BufferedReader br = new BufferedReader(fr);
				while((str = br.readLine()) != null)
				{
					stringarray = str.split(" ");
					detail_data_list.put(stringarray[0], Integer.parseInt(stringarray[1]));
				}
				fr.close();
				br.close();
		} catch (FileNotFoundException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		}
		
		return detail_data_list;
	}
	
	public void store_detail_graduation(HashMap <String, Integer> newthing, String Filename)
	{
		detail_data_list = newthing;
		
		try {
			File file = new File(Filename);
			file.delete();
			FileWriter fw = new FileWriter(Filename);
			BufferedWriter bw = new BufferedWriter(fw);
			for(String key : detail_data_list.keySet())
			{
				bw.write(key + " " + detail_data_list.get(key));
				bw.write("\n");
			}
			bw.close();
			detail_data_list.clear();
		} catch (IOException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		}
	}
}
