package Track;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Curriculum 
{
	private ArrayList <Subject> course = new ArrayList();
	
	public ArrayList<Subject> getCourse() {
		return course;
	}
	public void setCourse(ArrayList<Subject> course) {
		this.course = course;
	}
	
	public void getRequiredCourses(String Filename) // �������� �ҷ�����
	{
		CurriculumData d = new CurriculumData();
		course = d.Getdata(Filename);
		
		/*String str;
		String [] stringarr;
		
		try {
			FileReader fr = new FileReader(Filename);
			BufferedReader br = new BufferedReader(fr);
			while((str = br.readLine()) != null)
			{
				Subject new_subject = new Subject();
				
				stringarr = str.split(" ");
				
				new_subject.setSemester(Integer.parseInt(stringarr[0]));
				new_subject.setSchool_year(Integer.parseInt(stringarr[1]));
				new_subject.setSubject_name(stringarr[2]);
				new_subject.setSubject_code(stringarr[3]);
				new_subject.setGrade_point(Integer.parseInt(stringarr[4]));
				new_subject.setEssential(Integer.parseInt(stringarr[5]));
				
				course.add(new_subject);
			}
			fr.close();
			br.close();
		} catch (FileNotFoundException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		}*/	
	}
	
	public void delete_curriculum(int index) // �������� �����ϱ�
	{
		course.remove(index);
	}
	
	public void add_curriclum(int semester, int school_year, String subject_name, String subject_code, int grade_point, int essential)
	{
		Subject s = new Subject(semester, school_year, subject_name, subject_code, grade_point, essential);
		course.add(s);
	}
	
	public void store_curriculum(String Filename) // �������� �����ϱ�
	{
		CurriculumData d = new CurriculumData();
		d.Storedata(course, Filename);
		/*try {
			FileWriter fw = new FileWriter(Filename);
			BufferedWriter bw = new BufferedWriter(fw);
			for(Subject s : course)
			{
				fw.write(s.toString() + "\n");
			}
			fw.close();
			bw.close();
		} catch (IOException e) {
			System.out.println("���� �߻�. �����ڿ��� �����ϼ���.");
			e.printStackTrace();
		}*/
	}
}
